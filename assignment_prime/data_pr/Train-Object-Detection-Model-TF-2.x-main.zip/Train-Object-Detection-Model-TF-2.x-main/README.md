# Object Detection using Tensorflow 2.x
Train an SSD model for object-detection using Tensorflow 2.x (I have the labelmap file set with my custom classes for mask detection. You can use yours!)


